#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QStandardItemModel>
#include <QMap>
#include <heroes.h>
#include <QListView>
#include <QList>
#include "addnew.h"



namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

public:
    void openFile(const QString& file);
    QMap<QString, hero> _allHeroes;
//    QList forSorting;
//    QStringListModel* _namesOfHeroes;
    QStringListModel* getDetailModel() const  { return _namesOfHeroes; }

protected:
    /// Forms an absolute path to an image file by its relative path \a imgFileName.
    QString makeHeroImgPath(const QString& imgFileName);

private slots:
    void on_listOfHeroes_clicked(const QModelIndex &index);

    void on_searchLine_textChanged(const QString &arg1);

//    void on_addNewButton_clicked();



//public slots:
//    void slot(const hero& newHero);


    void on_addButton_clicked();

    void on_editButton_clicked();

private:
    Ui::Dialog *ui;
    QStringListModel* _namesOfHeroes;
    QString _pathToFolder;
    QList<hero> *_forSorting;
//    QStandardItemModel *model;
//    QStandardItemModel* _model;
//    addNew* win;





};

#endif // DIALOG_H
