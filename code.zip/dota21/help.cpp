#include "help.h"
#include "ui_help.h"
#include "about.h"

Help::Help(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Help)
{
    ui->setupUi(this);
    setWindowTitle("Help");
}

Help::~Help()
{
    delete ui;
}



void Help::on_aboutButton_clicked()
{
    About window;
    window.setModal(true);
    window.exec();


}


void Help::on_backButton_clicked()
{
    close();

}

