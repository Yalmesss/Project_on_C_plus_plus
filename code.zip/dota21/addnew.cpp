#include "addnew.h"
#include "ui_addnew.h"
#include "dialog.h"
#include "heroes.h"

addNew::addNew(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addNew)
{
    ui->setupUi(this);
//    dialog = new Dialog;
//    dialog->show();

//    connect(this, &addNew::signal, dialog,&Dialog::slot);
}

addNew::~addNew()
{
    delete ui;
}

void addNew::on_addButton_clicked()
{
    QString Agility = ui->placeForAgility->text();
    QString Strength = ui->placeForStrength_2->text();
    QString Name = ui->placeForName->text();
    QString Damage = ui->placeForDamage->text();
    QString Intelligence = ui->placeForIntelligence->text();

    hero newHero;
    newHero.name= Name;
    newHero.agility= Agility;
    newHero.strength= Strength;
    newHero.intelligence= Intelligence;
    newHero.damage= Damage;


   emit signal(newHero);
}


void addNew::on_cancelButton_clicked()
{
    close();
}

