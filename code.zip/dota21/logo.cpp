#include "logo.h"
#include <QPainter>

logo::logo(QWidget *parent)
    : QWidget{parent}
{

}

void logo::paintEvent(QPaintEvent* event)
{

    QPainter painter(this);


    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing, true);

    QBrush backGr(Qt::GlobalColor::darkRed);
    painter.setBrush(backGr);
    painter.drawRect(225,10,100,100);




    QBrush sward(Qt::GlobalColor::darkGray);
    painter.setBrush(sward);
    QPolygon pol;
    pol << QPoint(245,20)<<QPoint(235,20) << QPoint(235,30) <<QPoint(275,75) << QPoint(285,75)<< QPoint(285,65);
    painter.drawPolygon(pol);


    QColor r(39,56,69);
    QBrush ruc(r);
    painter.setBrush(ruc);
    QPolygon nizh;
    nizh << QPoint(285,75)<< QPoint(285,65) << QPoint(295,55) <<QPoint(305,55) << QPoint(295,65)<< QPoint(295,75) ;
    painter.drawPolygon(nizh);


    QPolygon verh;
    verh<< QPoint(285,75)<< QPoint(275,75) << QPoint(265,85) <<QPoint(265,95) << QPoint(275,85)<< QPoint(285,85);
    painter.drawPolygon(verh);

    QColor a(24,31,36);
    QBrush now(a);
    painter.setBrush(now);
    painter.drawRect(285,75,10,10);

    painter.drawRect(305,95,7,7);


    QColor b(77,69,57);
    QBrush calm(b);
    painter.setBrush(calm);
    QPolygon vse;
    vse << QPoint(295,80)<< QPoint(295,85) << QPoint(290,85) <<QPoint(305,100) << QPoint(305,95)<< QPoint(310,95) ;
    painter.drawPolygon(vse);



    QPen letters(Qt::GlobalColor::black,6);
    painter.setPen(letters);
    painter.drawArc(290,25,15,20,-95*16,190*16);
    painter.drawLine(290,25,290,45);

    painter.drawLine(255,78,240,78);
    painter.drawLine(255,85,255,88);
    painter.drawLine(255,88,245,88);
    painter.drawLine(240,96,255,96);
    painter.drawLine(240,89,240,88);


}
