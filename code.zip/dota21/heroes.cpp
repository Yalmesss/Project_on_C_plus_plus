#include "heroes.h"
#include <QFileInfo>

heroes::heroes()
{

}

void hero::fill(const QStringList &attrts)
{
    name = attrts[0];
    strength = attrts[1];
    agility = attrts[2];
    intelligence = attrts[3];
    damage = attrts[35];

}

QStringList hero::getInfoAsSList() const
{
    QStringList info;
    info << name << strength << agility << intelligence << damage ;//<< imgPath;
    return info;

}





QPixmap hero::makePathToImage(const QString& name, const QString& csvPath)
{
    QFileInfo csvFileName(csvPath);
    QString filePath = csvFileName.absolutePath() + "/" + "imgDota";

    QFile uniquePic = filePath + '/'+ name + ".png";

    if (uniquePic.exists())
    {
        QPixmap heroImg= filePath + '/'+ name + ".png";
        return heroImg;
    }
    else
    {
        QPixmap heroImg= filePath + '/'+ "Dota2" + ".png";
        return heroImg;
    }
}


