#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "dialog.h"
#include "help.h"
#include "heroes.h"
#include <QFile>
#include <QTextStream>
#include <QMap>
#include <heroes.h>
//#include <QStringListModel>
#include <QFileInfo>
//#include <QHBoxLayout>
#include <addnew.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    customizeUi();


}

MainWindow::~MainWindow()
{
    delete ui;

}


void MainWindow::on_startButton_clicked()
{
    Dialog window;
    window.setModal(true);
    window.exec();


}


void MainWindow::on_helpButton_clicked()
{
    Help window;
    window.setModal(true);
    window.exec();

}


void MainWindow::customizeUi()
{
    _logo = new logo(this);


    ui->gridLayout->addWidget(_logo);

}




