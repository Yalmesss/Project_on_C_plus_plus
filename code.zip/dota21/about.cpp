#include "about.h"
#include "ui_about.h"

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);
    setWindowTitle("About");
}

About::~About()
{
    delete ui;
}

void About::on_Close_clicked()
{
    close();
}

void About::paintEvent(QPaintEvent *)
{

    QPainter paint;






}

