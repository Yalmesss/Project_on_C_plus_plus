#ifndef HEROES_H
#define HEROES_H

#include <QObject>
#include <QString>
#include <QAbstractTableModel>
#include <QStringListModel>
#include <QPixmap>


struct hero
{

    QString name;
    QString strength;
    QString agility;
    QString intelligence;
    QString damage;
    QPixmap image;

    void fill(const QStringList& attrts);

    QStringList getInfoAsSList() const;

    QPixmap makePathToImage(const QString& name, const QString& path );

};

class heroes
{
public:
    heroes();
//    QAbstractTableModel* getMasterModel() const  { return _mainModel; }
//    QStringListModel* getDetailModel() const  { return _detailModel; }

//private:
//    QAbstractTableModel* _mainModel;

protected:
//    QAbstractTableModel* _mainmodel;
//    QMap<QString, hero*> _gamePers;
//    QStringListModel* _detailModel;



};

#endif // HEROES_H
