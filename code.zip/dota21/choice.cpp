#include "choice.h"
#include "ui_choice.h"

choice::choice(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::choice)
{
    ui->setupUi(this);
}

choice::~choice()
{
    delete ui;
}
