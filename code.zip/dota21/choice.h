#ifndef CHOICE_H
#define CHOICE_H

#include <QWidget>

namespace Ui {
class choice;
}

class choice : public QWidget
{
    Q_OBJECT

public:
    explicit choice(QWidget *parent = nullptr);
    ~choice();

private:
    Ui::choice *ui;
};

#endif // CHOICE_H
