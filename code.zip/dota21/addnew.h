#ifndef ADDNEW_H
#define ADDNEW_H

#include <QDialog>
//#include "dialog.h"
#include "heroes.h"

namespace Ui {
class addNew;
}

class addNew : public QDialog
{
    Q_OBJECT

public:
    explicit addNew(QWidget *parent = nullptr);
    ~addNew();

private slots:
    void on_addButton_clicked();

    void on_cancelButton_clicked();

private:
    Ui::addNew *ui;
//    Dialog* dialog;



signals:
    void signal(const hero& newHero);
};

#endif // ADDNEW_H
