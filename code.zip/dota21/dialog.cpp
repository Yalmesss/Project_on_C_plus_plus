#include "dialog.h"
#include "ui_dialog.h"
#include <QFile>
#include <QTextStream>
#include <QMap>
#include <heroes.h>
#include <QStringListModel>
#include <QFileInfo>
#include <QListWidgetItem>
#include <QDir>
#include <addnew.h>



Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)


{
//    QStandardItemModel *model = new QStandardItemModel();
    ui->setupUi(this);
    setWindowTitle("Heroes");
    _forSorting = new QList<hero>;

    _namesOfHeroes = new QStringListModel;
    _pathToFolder = "/Users/darianaumenko/DSBA Programming /Big_HW/Dota_heroes.csv";    //*сюда нужно вставить путь до папки с файлами*///
    this->openFile(_pathToFolder);
//    _model = new QStandardItemModel;                                                   //*папка с картинами должна находиться рядом с csv файлом(в одной папке)*//
//    win = new addNew;
//    win->show();
//  connect(win,SIGNAL(signal(const hero&)),this,SLOT(slot(const hero&)))*/;
//    connect(this,Dialog::slot(const hero&),win,addNew::signal(const hero&));




}




void Dialog::openFile(const QString& fileName)
{


    QFile file(fileName);

    if(!file.open(QIODevice::ReadOnly))
    {
        return;
    }



    bool firstLine = true;




    QTextStream fStream(&file);
    size_t t = 0;
    while (!fStream.atEnd())
    {

        QString line = fStream.readLine();
        if (!line.isNull() && !firstLine)
        {
            QStringList textDescr = line.split(QLatin1Char(','));
            for (size_t i = 0; i < textDescr.size(); ++i)
            {
                hero curHero;
                curHero.fill(textDescr);
                curHero.image = curHero.makePathToImage(curHero.name, _pathToFolder);
                QString name = textDescr[0];
                _allHeroes[name]= curHero;
//              _model->appendRow(new QStandardItem(QIcon(curHero.image), curHero.name))
            }

        }
        else
            firstLine = false;
        ++t;

    }

    file.close();

    QList<QString> keys = _allHeroes.keys();

    _namesOfHeroes->setStringList(keys);
    ui->listOfHeroes->setModel(_namesOfHeroes);

    //для картинок
//    ui->listOfHeroes->setModel(_model);
}







Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_listOfHeroes_clicked(const QModelIndex &index)
{
    QString heroName = index.data().toString();

    auto it = _allHeroes.find(heroName);
    hero selectedHero = *it;

    ui->placeForImage->setPixmap(selectedHero.image);
    ui->placeForAgility->setText("Agility: " + selectedHero.agility);
    ui->placeForIntelligence->setText("Intelligence: " + selectedHero.intelligence);
    ui->placeForName->setText("Name: " + selectedHero.name);
    ui->placeforStrength->setText("Strength: " + selectedHero.strength);
    ui->label_6->setText("Damage: " + selectedHero.damage);


}


void Dialog::on_searchLine_textChanged(const QString &arg1)
{
//    hide/*_all();
//    QList<QListWidgetItem*> matches ( ui->listOfHeroes->find(arg1) );
//    for(QListWidgetItem* item : matches)
//        item->setHidden(false);

////    model->match(model->index(0, 0), Qt::DisplayRole, QVariant::fromValue(search_text), -1, Qt::MatchStartsWith);

////    QListWidgetItem *item;
////    QList<QListWidgetItem *> found= findItems(arg1, Qt::MatchStartsWith);//возвращает пустой лист
////    for (int i=0;i<found.count();i++){
////        listWidget->setItemSelected(item,true);
////    }


//    const QRegExp rw (arg1);




//    if(listOfHeroes->filter(rw).isEmpty()) return;
//    QModelIndexList indexList = model->match(model->index(0, 0), Qt::DisplayRole, listNames.filter(rw).first());
//    if(indexList.isEmpty()) return;
//    QModelIndex selectedIndex(indexList.first());
//    myView->selectionModel()->setCurrentIndex(selectedIndex, QItemSelectionModel::ClearAndSelect);*/



//    model->setFilter(QDir::AllEntries | QDir::Files );
//    model->setNameFilterDisables(false);
//    model->setNameFilters(QStringList("*" + arg1 + "*"));
}





//void Dialog::on_addNewButton_clicked()
//{
//    addNew window;
//    window.setModal(true);
//    connect(win,SIGNAL(signal(const hero&)),this,SLOT(slot(const hero&)));
//    window.exec();

//}

//void Dialog::slot(const hero& newHero)
//{

//    _allHeroes[newHero.name]= newHero;
//    QList<QString> keys = _allHeroes.keys();
//    _namesOfHeroes->setStringList(keys);
//    ui->listOfHeroes->setModel(_namesOfHeroes);


//}


void Dialog::on_addButton_clicked()
{
    hero newHero;
    QString fool = ui->nameLine->text();
    newHero.name= fool;
    fool = ui->agilityLine->text();
    newHero.agility= fool;
    fool = ui->intelligenceLine->text();
    newHero.intelligence= fool;
    fool= ui->damageLine->text();
    newHero.damage= fool;
    fool = ui->agilityLine->text();
    newHero.agility= fool;
    newHero.image = newHero.makePathToImage(newHero.name, _pathToFolder);
    _allHeroes[newHero.name]= newHero;
    QList<QString> keys = _allHeroes.keys();
    _namesOfHeroes->setStringList(keys);
    ui->listOfHeroes->setModel(_namesOfHeroes);


}


void Dialog::on_editButton_clicked()
{

    hero newHero;
    QString fool = ui->nameLine->text();
    QString arg = ui->agilityLine->text();
    if ( arg != nullptr)
    {
        newHero= _allHeroes[fool];
        newHero.agility = arg;
        _allHeroes[fool]= newHero;

    }


    arg = ui->intelligenceLine->text();
    if ( arg != nullptr)
    {
        newHero= _allHeroes[fool];
        newHero.intelligence = arg;
        _allHeroes[fool]= newHero;

    }

    arg = ui->damageLine->text();
    if ( arg != nullptr)
    {
        newHero= _allHeroes[fool];
        newHero.damage = arg;
        _allHeroes[fool]= newHero;

    }


    arg = ui->strengthLine->text();
    if ( arg != nullptr)
    {
        newHero= _allHeroes[fool];
        newHero.strength = arg;
        _allHeroes[fool]= newHero;
    }

    newHero.image = newHero.makePathToImage(newHero.name, _pathToFolder);
    QList<QString> keys = _allHeroes.keys();
    _namesOfHeroes->setStringList(keys);
    ui->listOfHeroes->setModel(_namesOfHeroes);


}

